#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#define NUM_THREADS 4
#define TEXT_SIZE 100
// Struttura per i dati del thread
typedef struct {
  char *testo;
  int inizio;
  int fine;
  int *conteggio_parole;
} ThreadData;
// Funzione per contare le parole in una porzione di testo
void *conta_parole(void *arg) {
  ThreadData *data = (ThreadData *)arg;
  int conteggio = 0;
  int i = data->inizio;
  // Scorri il testo e conta le parole
  while (i < data->fine) {
    // Salta gli spazi vuoti
    while (i < data->fine && data->testo[i] == ' ') {
      i++;
    }
    // Se si trova una parola, incrementa il conteggio
    if (i < data->fine) {
      conteggio++;
      // Trova la fine della parola
      while (i < data->fine && data->testo[i] != ' ') {
        i++;
      }
    }
  }
  // Salva il conteggio delle parole nel thread data
  *data->conteggio_parole = conteggio;
  pthread_exit(NULL);
}
int main() {
  pthread_t threads[NUM_THREADS];
  ThreadData thread_data[NUM_THREADS];
  char testo[TEXT_SIZE];
  int conteggio_parole_totale = 0;
  int conteggio_parole_thread[NUM_THREADS];
  // Genera un testo casuale con spazi vuoti
  srand(time(NULL));
  for (int i = 0; i < TEXT_SIZE; i++) {
    testo[i] = (rand() % 2) ? (char)(rand() % 26 + 'a') : ' ';
  }
  testo[TEXT_SIZE - 1] = '\0'; // Aggiungi il terminatore di stringa
  printf("Testo: %s\n", testo);
  // Crea i thread per contare le parole in ogni porzione di testo
  for (int i = 0; i < NUM_THREADS; i++) {
    thread_data[i].testo = testo;
    thread_data[i].inizio = i * (TEXT_SIZE / NUM_THREADS);
    thread_data[i].fine = (i + 1) * (TEXT_SIZE / NUM_THREADS);
    thread_data[i].conteggio_parole = &conteggio_parole_thread[i];
    pthread_create(&threads[i], NULL, conta_parole, (void *)&thread_data[i]);
  }
  // Attendi che tutti i thread terminino
  for (int i = 0; i < NUM_THREADS; i++) {
    pthread_join(threads[i], NULL);
  }
  // Somma il conteggio delle parole di ogni thread
  for (int i = 0; i < NUM_THREADS; i++) {
    conteggio_parole_totale += conteggio_parole_thread[i];
  }
  printf("Numero totale di parole: %d\n", conteggio_parole_totale);
  return 0;
}

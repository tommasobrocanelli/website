﻿namespace FlippyBird
{
    partial class ucTuboSuperiore
    {
        /// <summary> 
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione componenti

        /// <summary> 
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare 
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ucTuboSuperiore));
            this.pbTuboSuperiore = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pbTuboSuperiore)).BeginInit();
            this.SuspendLayout();
            // 
            // pbTuboSuperiore
            // 
            this.pbTuboSuperiore.BackColor = System.Drawing.Color.Transparent;
            this.pbTuboSuperiore.Image = ((System.Drawing.Image)(resources.GetObject("pbTuboSuperiore.Image")));
            this.pbTuboSuperiore.Location = new System.Drawing.Point(3, 0);
            this.pbTuboSuperiore.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pbTuboSuperiore.Name = "pbTuboSuperiore";
            this.pbTuboSuperiore.Size = new System.Drawing.Size(112, 208);
            this.pbTuboSuperiore.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbTuboSuperiore.TabIndex = 9;
            this.pbTuboSuperiore.TabStop = false;
            this.pbTuboSuperiore.Tag = "tubo";
            // 
            // ucTuboSuperiore
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.pbTuboSuperiore);
            this.Name = "ucTuboSuperiore";
            this.Size = new System.Drawing.Size(137, 206);
            this.Load += new System.EventHandler(this.ucTuboSuperiore_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbTuboSuperiore)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pbTuboSuperiore;
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace FlippyBird
{
    public partial class FrmPunteggi : Form
    {
        string _nomeFile = "PunteggiFlappyBird.txt";
        public FrmPunteggi()
        {
            InitializeComponent();

        }
        private void popolaListView()
        {
            lviPunteggi.Items.Clear();
            for (int i = 0; i < Program._punteggio.Length; i++)
            {
                ListViewItem lvi = new ListViewItem(Program._punteggio[i].nomi);
                lvi.SubItems.Add(Program._punteggio[i].partita);
                lvi.SubItems.Add(Program._punteggio[i].punti.ToString());
                lviPunteggi.Items.Add(lvi);
            }
        }
        
        private void FrmPunteggi_Load(object sender, EventArgs e)
        {
            salvataggio();
            caricamento();
            popolaListView();
        }

        private void caricamento()
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.FileName = _nomeFile;

            ofd.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);

            // obbligo a scegiele un file esistente
            ofd.CheckFileExists = true;
            // imposto il filtro per i formati file
            ofd.Filter = "Tutti i file di testo (*.txt)|*.txt";
            ofd.Filter += "|Tutti i file (*.*)|*.*";
            ofd.FilterIndex = 1; // filtro predefinito

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                _nomeFile = ofd.FileName;
                // lettura di un file di testo
                StreamReader sr = new StreamReader(_nomeFile);
                // pulisco array in memoria
                int _numPartite = 0;
                Program._punteggio = new Program.sPunteggio[0];
                while (!sr.EndOfStream)
                {
                    string riga = sr.ReadLine();
                    string[] _partita = riga.Split('|');
                    if (_partita.Length == 3)
                    {
                        Array.Resize(ref Program._punteggio, Program._punteggio.Length + 1);
                        Program.sPunteggio _nuovoPunteggio = new Program.sPunteggio();
                        _nuovoPunteggio.nomi = Convert.ToString((_partita[0]));
                        _nuovoPunteggio.partita = Convert.ToString((_partita[1]));
                        _nuovoPunteggio.punti = Convert.ToInt16(_partita[2]);
                        Program._punteggio[Program._punteggio.Length - 1] = _nuovoPunteggio;
                        _numPartite++;

                    }
                }
                sr.Close();

            }
        }

        private void salvataggio()
        {
            string[] _punteggio = new string[Program._punteggio.Length];
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.FileName = _nomeFile;
            sfd.OverwritePrompt = true;
            sfd.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            sfd.Filter = "Tutti i file di testo (*.txt)|*.txt";
            sfd.Filter += "|Tutti i file (*.*)|*.*";
            sfd.FilterIndex = 1;
            if (sfd.ShowDialog() == DialogResult.OK)
            {
                string _nomeFile = sfd.FileName;
                StreamWriter sw = new StreamWriter(_nomeFile);
                for (int i = 0; i < Program._punteggio.Length; i++)
                {
                    string riga = Program._punteggio[i].nomi + "|";
                    riga += Program._punteggio[i].partita + "|";
                    riga += Program._punteggio[i].punti;
                    sw.WriteLine(riga);
                }
                sw.Close();
            }
        }

    }
}

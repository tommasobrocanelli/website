﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FlippyBird
{
    public partial class FrmFine : Form
    {
        public FrmFine()
        {
            InitializeComponent();
        }
        private string punteggioMassimo()
        {
            int _punteggioMassimo = Program._punteggio[0].punti;
            for (int i = 0; i < Program._punteggio.Length; i++)
            {
                if (_punteggioMassimo < Program._punteggio[i].punti)
                {
                    _punteggioMassimo = Program._punteggio[i].punti;
                }
            }

            return _punteggioMassimo.ToString();
        }

        private void btnInizia_Click(object sender, EventArgs e)
        {
            FrmAvvio frmAvvio = new FrmAvvio();
            frmAvvio.ShowDialog(this);
            this.Close();
        }

        private void btnClassifica_Click(object sender, EventArgs e)
        {
            FrmPunteggi frmPunteggi = new FrmPunteggi();
            frmPunteggi.ShowDialog(this);
        }

        private void FrmFine_Load(object sender, EventArgs e)
        {
            lblPunteggioFInale.Text = Program._punteggio[Program._punteggio.Length - 1].punti.ToString();
            lblMigliorPunteggio.Text = punteggioMassimo();
        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            FrmMenu frmMenu = new FrmMenu();
            frmMenu.ShowDialog(this);
            this.Close();
            //Program._punteggio[Program._punteggio.Length - 1].partita = string.Empty;
        }
    }
}

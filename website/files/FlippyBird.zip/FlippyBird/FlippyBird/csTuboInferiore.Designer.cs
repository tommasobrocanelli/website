﻿namespace FlippyBird
{
    partial class ucTuboInferiore
    {
        /// <summary> 
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione componenti

        /// <summary> 
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare 
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ucTuboInferiore));
            this.pbTuboInferiore = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pbTuboInferiore)).BeginInit();
            this.SuspendLayout();
            // 
            // pbTuboInferiore
            // 
            this.pbTuboInferiore.BackColor = System.Drawing.Color.Transparent;
            this.pbTuboInferiore.Image = ((System.Drawing.Image)(resources.GetObject("pbTuboInferiore.Image")));
            this.pbTuboInferiore.Location = new System.Drawing.Point(3, 2);
            this.pbTuboInferiore.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pbTuboInferiore.Name = "pbTuboInferiore";
            this.pbTuboInferiore.Size = new System.Drawing.Size(118, 176);
            this.pbTuboInferiore.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbTuboInferiore.TabIndex = 8;
            this.pbTuboInferiore.TabStop = false;
            this.pbTuboInferiore.Tag = "tubo";
            // 
            // ucTuboInferiore
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.pbTuboInferiore);
            this.Name = "ucTuboInferiore";
            this.Size = new System.Drawing.Size(124, 180);
            ((System.ComponentModel.ISupportInitialize)(this.pbTuboInferiore)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pbTuboInferiore;
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FlippyBird
{
    public partial class FrmGioco : Form
    {
        bool _salita = false;
        int _gravita = 7, _punteggio = 0, _yFinale;
        
        public FrmGioco()
        {
            InitializeComponent();
            timerDiscesa.Start();
            timerPavimento.Start();
            timerTubi.Start();
        }

        private void FrmGioco_Click_1(object sender, EventArgs e)
        {
            _salita = true;
            _yFinale = pbUccello.Location.Y - 60;
            timerSalita.Start();
        }

        private void timerPavimento_Tick_1(object sender, EventArgs e)
        {
            int _nuovaX = pbPavimento.Location.X - 10;
            pbPavimento.Location = new Point(_nuovaX, pbPavimento.Location.Y);
        }

        private void FrmGioco_Load(object sender, EventArgs e)
        {

        }

        private void timerTubi_Tick(object sender, EventArgs e)
        {
            Random rnd = new Random();
            int _posizioneYTuboInferiore = rnd.Next(265, 360);
            int _posizioneYTuboSuperiore = rnd.Next(-120, 10);
            int _offsetTubo = 17;
            pbTuboInferiore.Location = new Point(pbTuboInferiore.Location.X - _offsetTubo, pbTuboInferiore.Location.Y);
            pbTuboSuperiore.Location = new Point(pbTuboSuperiore.Location.X - _offsetTubo, pbTuboSuperiore.Location.Y);
            if (pbTuboSuperiore.Left < -80 || pbTuboInferiore.Left< -70)
            {
                pbTuboInferiore.Location = new Point(500, _posizioneYTuboInferiore);
                pbTuboSuperiore.Location = new Point(500, _posizioneYTuboSuperiore);
                _punteggio++;
            }
            lblPunteggio.Text = _punteggio.ToString();
        }
        private void timerDiscesa_Tick_1(object sender, EventArgs e)
        {
            if(!_salita)
            {
                int _nuovaYUccello = pbUccello.Location.Y + _gravita;
                if (pbUccello.Height != pbPavimento.Height)
                    pbUccello.Location = new Point(pbUccello.Location.X, _nuovaYUccello);
            }
            if(_salita)
            {
                for (int i = 0; i < 15; i++)
                {
                    if (pbUccello.Location.Y > _yFinale)
                    {
                        int _nuovaY = pbUccello.Location.Y - 4;
                        pbUccello.Location = new Point(pbUccello.Location.X, _nuovaY);
                    }
                }
                _salita = false;
            }
            foreach (Control controlloCorrente in this.Controls)
            {
                if (controlloCorrente is PictureBox)
                {
                    if (controlloCorrente.Tag != null && controlloCorrente.Tag.ToString() == "pavimento" || controlloCorrente.Tag.ToString() == "tubo")
                    {
                        if (pbUccello.Bounds.IntersectsWith(controlloCorrente.Bounds))
                        {
                            timerDiscesa.Stop();
                            timerPavimento.Stop();
                            timerTubi.Stop();
                            Program._numeroParita++;
                            Array.Resize(ref Program._punteggio, Program._punteggio.Length + 1);
                            Program._punteggio[Program._punteggio.Length - 1].nomi = Program._nomeInput;
                            Program._punteggio[Program._punteggio.Length - 1].punti = _punteggio;
                            Program._punteggio[Program._punteggio.Length - 1].partita = Program._numeroParita.ToString();
                            FrmFine frmFine = new FrmFine();
                            frmFine.ShowDialog(this);
                            this.Close();
                        }
                    }
                }
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FlippyBird
{
    public partial class FrmMenu : Form
    {
        public FrmMenu()
        {
            InitializeComponent();
        }

        private void btnInizia_Click(object sender, EventArgs e)
        {
            
            Program._nomeInput = tbNome.Text;
            if (Program._nomeInput != string.Empty && Program._nomeInput.Length > 1)
            {
                FrmAvvio frmAvvio = new FrmAvvio();
                frmAvvio.ShowDialog(this);
            }
            else
                MessageBox.Show("Inserire il nome");
            
        }

        private void btnPunteggi_Click(object sender, EventArgs e)
        {
            FrmPunteggi frmPunteggi = new FrmPunteggi();
            frmPunteggi.ShowDialog(this);
        }

        private void FrmMenu_Load(object sender, EventArgs e)
        {
            tbNome.Focus();
        }
    }
}

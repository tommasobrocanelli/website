﻿namespace FlippyBird
{
    partial class FrmPunteggi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lviPunteggi = new System.Windows.Forms.ListView();
            this.chNome = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.chNumeroPartita = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.chPunteggio = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.SuspendLayout();
            // 
            // lviPunteggi
            // 
            this.lviPunteggi.BackColor = System.Drawing.SystemColors.Window;
            this.lviPunteggi.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.chNome,
            this.chNumeroPartita,
            this.chPunteggio});
            this.lviPunteggi.HideSelection = false;
            this.lviPunteggi.Location = new System.Drawing.Point(64, 30);
            this.lviPunteggi.Name = "lviPunteggi";
            this.lviPunteggi.Size = new System.Drawing.Size(350, 454);
            this.lviPunteggi.TabIndex = 0;
            this.lviPunteggi.UseCompatibleStateImageBehavior = false;
            this.lviPunteggi.View = System.Windows.Forms.View.Details;
            // 
            // chNome
            // 
            this.chNome.Text = "Nome";
            this.chNome.Width = 100;
            // 
            // chNumeroPartita
            // 
            this.chNumeroPartita.Text = "Partita";
            this.chNumeroPartita.Width = 80;
            // 
            // chPunteggio
            // 
            this.chPunteggio.Text = "Punteggio";
            this.chPunteggio.Width = 80;
            // 
            // FrmPunteggi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Aqua;
            this.ClientSize = new System.Drawing.Size(494, 534);
            this.Controls.Add(this.lviPunteggi);
            this.Name = "FrmPunteggi";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FrmPunteggi";
            this.Load += new System.EventHandler(this.FrmPunteggi_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListView lviPunteggi;
        private System.Windows.Forms.ColumnHeader chNome;
        private System.Windows.Forms.ColumnHeader chNumeroPartita;
        private System.Windows.Forms.ColumnHeader chPunteggio;
    }
}
﻿namespace FlippyBird
{
    partial class FrmGioco
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmGioco));
            this.pbPavimento = new System.Windows.Forms.PictureBox();
            this.pbTuboInferiore = new System.Windows.Forms.PictureBox();
            this.pbTuboSuperiore = new System.Windows.Forms.PictureBox();
            this.pbUccello = new System.Windows.Forms.PictureBox();
            this.timerDiscesa = new System.Windows.Forms.Timer(this.components);
            this.timerPavimento = new System.Windows.Forms.Timer(this.components);
            this.timerTubi = new System.Windows.Forms.Timer(this.components);
            this.lblPunteggio = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.timerSalita = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.pbPavimento)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbTuboInferiore)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbTuboSuperiore)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbUccello)).BeginInit();
            this.SuspendLayout();
            // 
            // pbPavimento
            // 
            this.pbPavimento.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbPavimento.Image = ((System.Drawing.Image)(resources.GetObject("pbPavimento.Image")));
            this.pbPavimento.Location = new System.Drawing.Point(-4, 533);
            this.pbPavimento.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pbPavimento.Name = "pbPavimento";
            this.pbPavimento.Size = new System.Drawing.Size(17056, 75);
            this.pbPavimento.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbPavimento.TabIndex = 3;
            this.pbPavimento.TabStop = false;
            this.pbPavimento.Tag = "pavimento";
            // 
            // pbTuboInferiore
            // 
            this.pbTuboInferiore.BackColor = System.Drawing.Color.Transparent;
            this.pbTuboInferiore.Image = ((System.Drawing.Image)(resources.GetObject("pbTuboInferiore.Image")));
            this.pbTuboInferiore.Location = new System.Drawing.Point(515, 404);
            this.pbTuboInferiore.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pbTuboInferiore.Name = "pbTuboInferiore";
            this.pbTuboInferiore.Size = new System.Drawing.Size(96, 234);
            this.pbTuboInferiore.TabIndex = 7;
            this.pbTuboInferiore.TabStop = false;
            this.pbTuboInferiore.Tag = "tubo";
            // 
            // pbTuboSuperiore
            // 
            this.pbTuboSuperiore.BackColor = System.Drawing.Color.Transparent;
            this.pbTuboSuperiore.Image = ((System.Drawing.Image)(resources.GetObject("pbTuboSuperiore.Image")));
            this.pbTuboSuperiore.Location = new System.Drawing.Point(416, -19);
            this.pbTuboSuperiore.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pbTuboSuperiore.Name = "pbTuboSuperiore";
            this.pbTuboSuperiore.Size = new System.Drawing.Size(90, 251);
            this.pbTuboSuperiore.TabIndex = 8;
            this.pbTuboSuperiore.TabStop = false;
            this.pbTuboSuperiore.Tag = "tubo";
            // 
            // pbUccello
            // 
            this.pbUccello.Image = ((System.Drawing.Image)(resources.GetObject("pbUccello.Image")));
            this.pbUccello.Location = new System.Drawing.Point(17, 295);
            this.pbUccello.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pbUccello.Name = "pbUccello";
            this.pbUccello.Size = new System.Drawing.Size(48, 44);
            this.pbUccello.TabIndex = 11;
            this.pbUccello.TabStop = false;
            this.pbUccello.Tag = "uccello";
            // 
            // timerDiscesa
            // 
            this.timerDiscesa.Interval = 50;
            this.timerDiscesa.Tick += new System.EventHandler(this.timerDiscesa_Tick_1);
            // 
            // timerPavimento
            // 
            this.timerPavimento.Interval = 50;
            this.timerPavimento.Tick += new System.EventHandler(this.timerPavimento_Tick_1);
            // 
            // timerTubi
            // 
            this.timerTubi.Tick += new System.EventHandler(this.timerTubi_Tick);
            // 
            // lblPunteggio
            // 
            this.lblPunteggio.AutoSize = true;
            this.lblPunteggio.BackColor = System.Drawing.Color.Transparent;
            this.lblPunteggio.Font = new System.Drawing.Font("Arial", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPunteggio.Location = new System.Drawing.Point(140, 30);
            this.lblPunteggio.Name = "lblPunteggio";
            this.lblPunteggio.Size = new System.Drawing.Size(25, 27);
            this.lblPunteggio.TabIndex = 6;
            this.lblPunteggio.Text = "0";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Arial", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(122, 27);
            this.label1.TabIndex = 5;
            this.label1.Text = "Punteggio";
            // 
            // timerSalita
            // 
            this.timerSalita.Interval = 50;
            // 
            // FrmGioco
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Aqua;
            this.ClientSize = new System.Drawing.Size(690, 602);
            this.Controls.Add(this.lblPunteggio);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pbPavimento);
            this.Controls.Add(this.pbTuboSuperiore);
            this.Controls.Add(this.pbTuboInferiore);
            this.Controls.Add(this.pbUccello);
            this.DoubleBuffered = true;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "FrmGioco";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FrmGioco";
            this.Load += new System.EventHandler(this.FrmGioco_Load);
            this.Click += new System.EventHandler(this.FrmGioco_Click_1);
            ((System.ComponentModel.ISupportInitialize)(this.pbPavimento)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbTuboInferiore)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbTuboSuperiore)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbUccello)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pbPavimento;
        private System.Windows.Forms.PictureBox pbTuboInferiore;
        private System.Windows.Forms.PictureBox pbTuboSuperiore;
        private System.Windows.Forms.PictureBox pbUccello;
        private System.Windows.Forms.Timer timerDiscesa;
        private System.Windows.Forms.Timer timerPavimento;
        private System.Windows.Forms.Timer timerTubi;
        private System.Windows.Forms.Label lblPunteggio;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Timer timerSalita;
    }
}
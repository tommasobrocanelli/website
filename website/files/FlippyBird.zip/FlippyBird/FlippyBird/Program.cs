﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FlippyBird
{
     public static class Program
     {
        public static int _numeroParita = 0;
        public static string _nomeInput;
        public struct sPunteggio
        {
            public string nomi;
            public string partita;
            public int punti;
        }
        public static sPunteggio[] _punteggio = new sPunteggio[0];
        /// <summary>
        /// Punto di ingresso principale dell'applicazione.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new FrmMenu());
        }
     }
}

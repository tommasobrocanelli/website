﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FlippyBird
{
    public partial class FrmAvvio : Form
    {
        public FrmAvvio()
        {
            InitializeComponent();
        }
        
        private void FrmAvvio_Click(object sender, EventArgs e)
        {
            FrmGioco frmGioco = new FrmGioco();
            frmGioco.ShowDialog(this);
            this.Close();
        }

        private void FrmAvvio_Load(object sender, EventArgs e)
        {

        }
    }
}
